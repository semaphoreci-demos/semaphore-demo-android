package com.semaphoreci.demo.network.errors

data class ServerError(val message: String)
